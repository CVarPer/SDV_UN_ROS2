# Firebase-Coms

Server to administrate the connection between Firebase and ROS

## Installation

Download or clone this repository

    $ git clone https://gitlab.com/LabFabEx/firebase-coms.git

Make sure '/src/robots/opcda' path is not empty, if it is then clone recursively the submodule and if it's the first time you'll need to add the 'init' flag and the update

    $ git submodule init
    $ git submodule update

If the folder is still empty then contact LabFabEx researchers for SSH Key adding

### Pre-requisites

To run the project you will need

- Node.js 6.14.3, LTS: Boron, date: 2018-06-12, V8: 5.1.281.111
npm 3.10.10, node module version: 48

optional downloads

    $ npm i yarn -g
    $ npm i curl -g

In the root folder of the proyect (/firebase-coms) run

    $ npm install
    or
    $ yarn install

### Run

Set the following environment variables

- ROBOT_NAME
- ROBOT_TYPENAME

On Windows type in terminal

    $ setx ROBOT_NAME <robotName>
    $ setx ROBOT_TYPENAME <robotType>

For example:

    $ setx ROBOT_NAME ANTENNAS
    $ setx ROBOT_TYPENAME OPC

Then start the server

    $ npm run start
    or
    $ yarn start

## Connect the robot

To start the connection between the library and Firebase, an HTTP POST request must be sent. If you're using cURL, use the following command with the appropriate `server_ip`.

    $ curl -X POST server_ip/connect

for example:

    $ curl -X POST localhost:3000/connect

## Post the task

To post the task on Firebase an HTTP POST request must be sent. If you're using cURL, use the following command with the appropriate `server_ip`.

    $ curl -X POST server_ip/genTask

for example:

    $ curl -X POST localhost:3000/genTask

## Modify the task

To create tasks, a temporary endpoint was created `/generateTask`.

To modify the existing task or create a new one, modify the file `task_generator.ts`.
Every robot involved must call the method `generateRobotTask` using the appropriate `steps` and `metadata`.
After all modifications have been made.

Finally re-start the server.