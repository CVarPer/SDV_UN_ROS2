import { QuerySnapshot, QueryDocumentSnapshot } from "@google-cloud/firestore";


export abstract class ProcessTracker {

    
    abstract onNewProcess(process: QueryDocumentSnapshot): void
    
}