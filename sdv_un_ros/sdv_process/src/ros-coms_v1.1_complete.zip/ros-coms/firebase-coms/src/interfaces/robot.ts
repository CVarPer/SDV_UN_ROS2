
export abstract class Robot {

    onDisconnect: () => void = ()=>{};

    abstract get id(): string;

    abstract start(): Promise<boolean>;

    abstract processCommand(
        type: string,
        args: any,
        onSuccess: () => void,
        onError: (error: string) => void,
        onWarning?: (warning: string) => void
    ): void;

    abstract stop(): Promise<boolean>;

}  