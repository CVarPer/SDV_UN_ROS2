import { Step } from "../_models";

export abstract class StepTracker {
    abstract onStepReady(step: Step): void
}