#!/usr/bin/env bash

BASEDIR=$(dirname "$0")
node -v
node "$BASEDIR/../../dist/functions/index.js"
