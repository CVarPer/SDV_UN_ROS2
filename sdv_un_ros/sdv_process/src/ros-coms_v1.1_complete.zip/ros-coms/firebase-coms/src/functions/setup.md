Run the following commands


```
BASEDIR=$(dirname "$0")
chmod +x "$BASEDIR/pria-heartbeat.sh"
crontab -e
```

Enter the job:

```
*/10 * * * * "[path-to-folder]/pria-heartbeat.sh"
``` 