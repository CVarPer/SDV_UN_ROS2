import { FirebaseManager } from '../firebase/firebase_manager';
import { collections, fields } from '../firebase';


async function deactivateRobots() {
    const manager = new FirebaseManager();
    const robotsQuerySnap = await manager.db()
        .collection(collections.ROBOTS)
        .get();

    robotsQuerySnap.forEach(
        robot => robot.ref.update({ [fields.ACTIVE]: false })
    );
}

deactivateRobots();