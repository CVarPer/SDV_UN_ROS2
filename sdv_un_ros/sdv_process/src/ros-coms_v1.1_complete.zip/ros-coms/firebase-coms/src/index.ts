
import { App } from './App'
import { ProcessManager } from './managers';
import { Robot } from './interfaces';

const port = process.env.PORT || 3000

function init() {

  var rob = new MockRobot()
  var pm = new ProcessManager(rob)

  const app = new App(pm)

  app.start(port)
}

class MockRobot implements Robot {
  onDisconnect: () => void = () => { };
  get id(): string {
    return 'TEST'
  }

  async start(): Promise<boolean> {
    return true
  }

  processCommand(type: string, args: any, onSuccess: () => void, onError: (error: string) => void, onWarning?: (warning: string) => void): void {
    onSuccess()
  }

  async stop(): Promise<boolean> {
    return true
  }

}

init()