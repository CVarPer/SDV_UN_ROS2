/**
 * Created by sac on 24/04/17.
 */

import * as admin from 'firebase-admin'
import { Firestore } from '@google-cloud/firestore';
import { ServiceAccountCredentials, FirebaseConfig } from './serviceAccountCredentials'

export class FirebaseManager {

  private static isInitialized: boolean = false
  private database: FirebaseFirestore.Firestore


  constructor() {
    try {
      if (!FirebaseManager.isInitialized) {

        const serviceAccount = ServiceAccountCredentials as admin.ServiceAccount
        admin.initializeApp({
          credential: admin.credential.cert(serviceAccount),
          databaseURL: FirebaseConfig.databaseURL,
        })
        FirebaseManager.isInitialized = true
      }

      this.database = admin.firestore()

    } catch (error) {
      console.error('Error initializing firestore', error)
    }

  }

  db(): Firestore {
    if (!FirebaseManager.isInitialized) {
      throw Error('Firebase not initialized')
    }
    return this.database
  }

}

