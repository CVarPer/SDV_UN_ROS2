
// Collections
const STEPS = 'Steps'
const PROCESSES = 'Processes'

const ROBOTS = 'Robots'

export const collections = {
    STEPS,
    PROCESSES,
    ROBOTS
}


// Fields
const ROBOT = 'robot'
const ACTIVE = 'active'
const STATUS = 'status'

const ERROR = 'error'
const HIATUS = 'hiatus'
const SUCCESS = 'success'
const WARNING = 'warning'
const IN_PROGRESS = 'in_progress'

export const fields = {
    ROBOT,
    ACTIVE,
    STATUS,
    SUCCESS,
    WARNING,
    ERROR,
    IN_PROGRESS,
    HIATUS
}
