import { FirebaseManager } from "./firebase_manager";
import { ProcessTracker } from "../interfaces";
import { collections, fields } from "./keys";
import { StatusListener } from "./status_listener";
import { CollectionReference, DocumentReference } from "@google-cloud/firestore";

export class ProcessListener {

    robotId: string;
    robot: ProcessTracker;
    firebase: FirebaseManager;
    dbclose: () => void = () => { };
    statusListener: any;

    constructor(robotId: string, robot: ProcessTracker) {
        this.robotId = robotId
        this.robot = robot
        this.firebase = new FirebaseManager()

        this.init.bind(this)
        this.remove.bind(this)
        this.close.bind(this)

        this.statusListener = new StatusListener(this.robotRef);

    }

    private get robotRef(): DocumentReference {
        return this.firebase.db()
            .collection(collections.ROBOTS)
            .doc(this.robotId);
    }

    // Helper method for quick access to Processes collection
    private processess(): CollectionReference {
        return this.robotRef.collection(collections.PROCESSES)
    }

    /** 
     *
    */
    init() {
        this.robotRef.update({ [fields.ACTIVE]: true });
        this.statusListener.start();
        this.dbclose = this.processess()
            .onSnapshot(
                (snap) => {
                    snap.docChanges().forEach(change => {
                        if (change.type != 'added') return
                        console.log('Got new process')
                        this.robot.onNewProcess(change.doc)
                    })

                },
                (error) => console.error('Process snapshot error', error)
            )
    }

    remove(processId: string) {
        this.processess()
            .doc(processId)
            .delete()
    }

    close() {
        this.dbclose();
        this.statusListener.stop();
        this.robotRef.update({ [fields.ACTIVE]: false })
    }

}