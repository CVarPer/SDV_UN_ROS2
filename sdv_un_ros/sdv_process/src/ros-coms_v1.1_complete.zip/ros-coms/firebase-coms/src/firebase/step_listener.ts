import { CollectionReference, QueryDocumentSnapshot, DocumentReference, Timestamp } from "@google-cloud/firestore";
import * as async from "async";

import { FirebaseManager } from "./firebase_manager";
import { collections, fields } from "./keys";
import { StepTracker } from "../interfaces";
import { Step } from "../_models";


export class StepListener {

    robotId: string;

    firebase: FirebaseManager;
    stepTracker: StepTracker;
    dbRefs: [() => void] = [() => { }];

    constructor(robotId: string, stepTracker: StepTracker) {
        this.robotId = robotId
        this.stepTracker = stepTracker

        this.firebase = new FirebaseManager()

        this.steps.bind(this)
        this.process.bind(this)
        this.start.bind(this)
        this.listenFor.bind(this)
        this.prevStepDone.bind(this)
        this.unsub.bind(this)
        this.close.bind(this)

    }

    steps(processId: string): CollectionReference {
        return this.process(processId)
            .collection(collections.STEPS)
    }


    process(processId: string): DocumentReference {
        return this.firebase.db()
            .collection(collections.PROCESSES)
            .doc(processId)
    }


    async start(processId: string, callback: (error: string, success: boolean) => void) {

        let querySnapshot = await this.steps(processId)
            .where(fields.ROBOT, '==', this.robotId)
            .get()
        let querySnapshots = []
        querySnapshot.forEach(doc => querySnapshots.push(doc))

        if (!querySnapshots.length) {
            callback(null, true)
            return
        }
        async.every(querySnapshots,
            (docSnapshot: QueryDocumentSnapshot, callback: (error: string, success: boolean) => void) => {
                this.listenFor(docSnapshot, processId, callback)
            },
            callback
        )
    }


    private listenFor(docSnapshot: QueryDocumentSnapshot, processId: string, callback: (error: string, success: boolean) => void) {
        let step = docSnapshot.data()
        if (step.status == fields.SUCCESS || step.status == fields.ERROR) return

        let prevSteps = step.prev_step as DocumentReference[] || []

        console.log(`${prevSteps.length} PrevSteps`)

        async.every(
            prevSteps,
            (prevStep: DocumentReference, callback: (error: string, success: boolean) => void) => {
                return this.prevStepDone(
                    prevStep, processId, docSnapshot, callback
                )
            },
            (error: string, success: boolean) => {
                if (success) {
                    const timestamp = Timestamp.fromDate(new Date())
                    console.log('step ready to execute')
                    this.steps(processId).doc(docSnapshot.id).update({
                        [fields.STATUS]: fields.IN_PROGRESS,
                        startDate: timestamp
                    })
                    const newStep = new Step(processId, docSnapshot.id, step, callback)
                    this.stepTracker.onStepReady(newStep)
                } else {
                    console.log('previous step has failed')
                    this.steps(processId).doc(docSnapshot.id).update({
                        [fields.STATUS]: fields.ERROR
                    })
                }
            }
        )
    }


    prevStepDone(
        prevStep: DocumentReference,
        processId: string,
        docSnapshot: QueryDocumentSnapshot,
        callback: (error: string, success: boolean) => void) {

        let prevStepListener = prevStep.onSnapshot(
            (pDocSnapshot) => {
                let prevStepData = pDocSnapshot.data()

                if (prevStepData.status == fields.SUCCESS) {
                    this.unsub(prevStepListener)
                    callback(null, true)
                } else if (prevStepData.status == fields.WARNING) {
                    console.log('step on warning')
                    this.steps(processId).doc(docSnapshot.id).update({
                        [fields.STATUS]: fields.WARNING
                    })
                } else if (prevStepData.status == fields.ERROR) {
                    this.unsub(prevStepListener)
                    callback(null, false)
                }
            }
        )
        this.dbRefs.push(prevStepListener)

    }


    unsub(unsubFunc: () => void) {
        unsubFunc()
        let idx = this.dbRefs.indexOf(unsubFunc)
        if (idx > 0)
            this.dbRefs.splice(idx, 1)
    }


    close() {
        this.dbRefs.forEach(
            unsub => unsub()
        )
    }

}