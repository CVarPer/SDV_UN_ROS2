import { FirebaseManager } from "./firebase_manager";
import { collections, fields } from ".";
import { DocumentReference } from "@google-cloud/firestore";

export class StatusListener {

  robotRef: DocumentReference;
  dispose: () => void;


  constructor(robotRef: DocumentReference) {
    this.robotRef = robotRef;
  }

  start() {
    this.dispose = this.robotRef.onSnapshot(snap => {
      const { active } = snap.data();
      if (active) return;

      this.robotRef.update({ active: true });
    });

  }

  stop() {
    this.dispose();
  }
}
