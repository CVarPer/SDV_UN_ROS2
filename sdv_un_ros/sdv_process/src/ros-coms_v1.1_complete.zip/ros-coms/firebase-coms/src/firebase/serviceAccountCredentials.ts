export const ServiceAccountCredentials = {
  "type": "service_account",
  "project_id": "pria-un",
  "private_key_id": "d41da29392eb20c0566ef4828a4c50c1bf3a0d48",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCn0rggge69VbaC\nWMIgsiiexO4wbNcJ1kUv3dUQNgRIf0SMy0m8RC4uO9UkH+IQpeiyFStzkb3Ib27v\n38RKfuWb/rXN9BxFptzi2QoYmmlM3XHpzmWlQ3jSlAunE9ziLsrZzSseG6NQRuU+\nvNI+Fe1QQ8iczj1BNWZmaghQafjHSzejnG52leOuTeyvogJHwj3PI0Um2v1zHJhi\nBasK0w5T78S7LHKFbj5njMDIsbFPL6wRSGqDdvTBE5xOVSFOMT2GWDtscXH4JmGz\ndKL6cuGPvfBbSaGpKJUHOwKU1jRmZp5RodsLFH/2ZwlGZjyAU1SJoEtD81q2L+E4\nm8teHH63AgMBAAECggEAOlEljZpJET73MF1SfBUcu2s4T9iKcw8jtKnzz3HN1Dlx\nYzGDGmpg180P2EFCB8H3Vea4Vi0XU06xsKZD6hUliasdlwdUSbnduPBtqzYBEGZF\nHteLh72l/xrV38WttGVJNR0v9gLpocw4/i+UKWHqOMGNNTwPmhjJ0B3ZbMQeYHYH\n8Xqs8Io2LnXuclhYZy00aQIRm4iPyIu9f6WT6FNhKf4nh74ROMadZf8kvPRi3kTM\nHUqV0i8Yi6KXrKomadWQs3YNsXaSLnR0/YhSf5wQLb4Mef9+zIpIfg6DxK8c/VRT\nTCF73OpRpJAvPgpDPkB+WbGZSMc8PizT+svqiDjgFQKBgQDtDQWDc1EPLGQMBkOd\nEpzvY47EW9xCCY6Kq54IG5jZueAVsKrnA33n715UDeLlu+x3Jugsdtsf/3RTmZrq\n08LZMQsXU/Cr36fqsa2+fFMfI85ftsXu2K9P2hK0uWU0EDa1lFIiYh6IqCyLOtf9\nXuiWmdGTxi01dKMu5NwRr51tPQKBgQC1PQeyFGG9ZM2rQ1omJnPNXS4wy1STutss\nQYY2NKeu2b/9TZBd5f99JiG/aaxqi68jyHWN5zudmV8sHesVMBO0I6yqm2FukPgl\nKQzIsbEr6o8bpPVzJ8hePBR4muEYkUz9EF/nK9yd2waQ7X8uKABpMA6IboIhfFQl\ndRuw47aDAwKBgARowJiAVZqlpbq/hxRt2zNss6QdXUxxJxCXPppCASbTmUJuBc/E\nNdxRjHydwYGqbCyPMbRaBZtjwgMoEUSa6b3mdqFZc1mPEG2CHowzfcxPezA2kxnt\nN92RXdW0uRgt0QaxmpF/J7g9AI8aahgRYtwiQk6wWfjrkXl20k0V6iS1AoGAS2cC\nxqIYL/W6Y6B35xtkXnJ//yj5HSVGflkcf3zUrrhFWhtlDsvbybONotdSNlm7GgYS\ncmFbuivPHsmrvnrsF6wn8CsJFDkYJE251d2nun+x3mx4+dn5UMtqMOsu70u0Xizr\n2X+0H7C6QJ2upgNaeGjYAwcG+OuDDrp0NNnoWwUCgYEAvPm+XQnPtFp1ZCoHV1TQ\ndctfp/3DHTh98DSTVBociDiMjuwR8YrmAO49i9c7rI6qp3EXxtHNyyMuegVb2tju\nzXEP++fYhFnkDkFPQ8KDbIygRyw0oZK4ZJYsHNgHrhUS8eLQzS/pIkBgM+pemMAI\n7bitIbl1zK+WoZTkqM/pGEw=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-zanyv@pria-un.iam.gserviceaccount.com",
  "client_id": "111872297159503761302",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-zanyv%40pria-un.iam.gserviceaccount.com"
}

export const FirebaseConfig = {
  databaseURL: "https://pria-un.firebaseio.com"
}