
import * as moment from 'moment';
import { Step } from "../_models";
import { Robot, StepTracker } from "../interfaces";
import { StepListener, fields } from "../firebase";

export class StepManager implements StepTracker {

    currentStep: Step
    stepQueue: Step[] = []
    robot: Robot;
    stepListener: StepListener;
    stepStartDate: moment.Moment;

    constructor(robot: Robot) {
        this.robot = robot
        this.stepListener = new StepListener(robot.id, this)

        this.onStepReady.bind(this)
        this.nextStep.bind(this)
        this.execute.bind(this)

    }

    onStepReady(step: Step): void {
        this.stepQueue.push(step)
        if (this.currentStep) {
            console.log('received step while another is in progress... enqueueing')
            return
        }
        this.nextStep.bind(this)()
    }

    nextStep() {

        if (this.stepQueue.length < 1) {
            console.log('empty queue')
            return
        }
        this.currentStep = this.stepQueue.shift()
        this.stepStartDate = moment()
        this.execute()
            .catch((error) => console.error(error))
            .finally(() => {
                console.log('finished step')
                this.currentStep = null
                this.nextStep.bind(this)()
            })
    }

    execute(): Promise<void> {
        let step = this.currentStep
        console.log('executing step', step)
        const gd = () => {
            const diff = moment().diff(this.stepStartDate)
            this.stepStartDate = null
            return diff
        }
        return new Promise<void>(
            (resolve, reject) => {
                this.robot.processCommand(step.type, step.args,
                    () => {
                        console.log('step success')
                        const elapsedTime = gd()
                        this.stepListener.steps(step.processId).doc(step.stepId)
                            .update({ [fields.STATUS]: fields.SUCCESS, duration: elapsedTime })
                        step.callback(null, true)
                        resolve()
                    },
                    (error) => {
                        console.log('step error', error)
                        const elapsedTime = gd()
                        this.stepListener.steps(step.processId).doc(step.stepId)
                            .update({ [fields.STATUS]: fields.ERROR, error, duration: elapsedTime })
                        this.stepListener.process(step.processId)
                            .update({ [fields.STATUS]: fields.ERROR, error })
                        step.callback(error, false)
                        reject(error)
                    },
                    (warning) => {
                        console.log('step warning', warning)
                        const elapsedTime = gd()
                        this.stepListener.steps(step.processId).doc(step.stepId)
                            .update({ [fields.STATUS]: fields.WARNING, warning, duration: elapsedTime })
                        this.stepListener.process(step.processId)
                            .update({ [fields.STATUS]: fields.WARNING })
                    }
                )
            }
        );
    }

    stop() {
        this.currentStep = null
        this.stepQueue = []

        this.stepListener.close()
    }

    /** Starts listening for steps that can be done on a process
     *  Returns once all steps have been finished
     */
    start(processId: string) {

        const executor = (resolve: any, _reject: any) =>
            this.stepListener.start(processId,
                (_error: string, _success: boolean) => resolve()
            )

        return new Promise<void>(executor)
    }
}
