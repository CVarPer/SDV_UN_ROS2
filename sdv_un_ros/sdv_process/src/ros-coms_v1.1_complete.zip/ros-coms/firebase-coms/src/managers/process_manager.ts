import { QueryDocumentSnapshot } from "@google-cloud/firestore";

import { ProcessListener } from "../firebase";
import { ProcessTracker, Robot } from "../interfaces";
import { StepManager } from "./step_manager";

export class ProcessManager implements ProcessTracker {

    stepManager: StepManager;

    processListener: ProcessListener

    currentProcess: string
    processQueue: string[] = []
    robot: Robot;


    constructor(robot: Robot) {

        this.robot = robot
        this.robot.onDisconnect = this.clear.bind(this)
        this.processListener = new ProcessListener(robot.id, this)

        this.stepManager = new StepManager(robot)

        this.onNewProcess.bind(this)
        this.nextProcess.bind(this)
        this.execute.bind(this)

    }

    async init(): Promise<boolean> {
        let success = await this.robot.start()
        if (success) {
            this.processListener.init();
            console.log(`Robot ${this.robot.id} connected`);
        }
        return success;
    }

    async stop() {
        this.robot.stop()
        this.clear()
    }

    private clear() {
        this.currentProcess = null
        this.processQueue = []

        this.processListener.close()
        this.stepManager.stop()
    }

    onNewProcess(process: QueryDocumentSnapshot) {

        this.processQueue.push(process.id)
        if (this.currentProcess) {
            console.log('received process while another is in progress... enqueueing')
            return
        }

        this.nextProcess.bind(this)()
    }


    nextProcess() {
        if (this.processQueue.length < 1) {
            console.log('process queue empty')
            return
        }

        this.currentProcess = this.processQueue.shift()
        this.execute().then(() => {
            console.log(`Finished process ${this.currentProcess}`)
            this.processListener.remove(this.currentProcess)
            this.currentProcess = null
            this.nextProcess.bind(this)()
        })
    }

    execute(): Promise<void> {
        return this.stepManager.start(this.currentProcess)
    }

    onDisconnect() {
        this.stop.bind(this)()
    }

}