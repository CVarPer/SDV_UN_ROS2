import { DocumentData } from "@google-cloud/firestore";

export class Step {
    type: string
    args: any
    processId: string;
    stepId: string;
    callback: (error: string, success: boolean) => void

    constructor(processId: string, stepId: string, stepData: DocumentData, callback: (error: string, success: boolean) => void) {
        this.processId = processId
        this.stepId = stepId
        this.type = stepData.type
        this.args = stepData.args
        this.callback = callback
    }

}