import * as _ from 'lodash';
import * as express from 'express'
import * as bodyParser from "body-parser"

import { ProcessManager } from './managers';

export class App {
  private express
  private processManager: ProcessManager;

  constructor(processManager: ProcessManager) {
    this.processManager = processManager
    this.express = express()
    this.mountRoutes()
  }

  private mountRoutes(): void {
    this.express.use(bodyParser.urlencoded({
      extended: false
    }))
    this.express.use(bodyParser.json())
    const router = express.Router()

    router.post('/connect', (_req, res) => {
      console.log("App: POST Connect ");
      this.processManager.init().then((success) => {
        if (success)
          res.json(
            { status: 200, text: 'OK' }
          )
        else
          res.json(
            { status: 500, text: 'Failed' }
          )
      })
    })
    
    router.post('/disconnect', (_req, res) => {
      this.processManager.stop().then(() => {
        res.json(
          { status: 200, text: 'OK' }
        )
      })
    })

    this.express.use('/', router)
  }

  start(port) {
    this.express.listen(port, (err: any) => {
      if (err) {
        return console.log(err)
      }
      return console.log(`server is listening on ${port}`)
    })
  }
}
