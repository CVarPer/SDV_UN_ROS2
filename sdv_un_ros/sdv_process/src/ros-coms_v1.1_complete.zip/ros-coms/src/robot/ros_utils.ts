

import { Topic, Message } from 'roslib';

const DEBUG = 1 //debug level
const INFO = 2  //general level
const WARN = 4  //warning level
const ERROR = 8 //error level
const FATAL = 16 //fatal/critical level

export const logLvl = {
    DEBUG,
    INFO,
    WARN,
    ERROR,
    FATAL
}

/**
 * Simple ROS topic creation 
 * @param {*} ros 
 * @param {*} name 
 * @param {*} messageType 
 */
export function getTopic(ros, name, messageType): Topic {

    return new Topic({
        ros,
        name,
        messageType
    });
}

export function getMessage(msg): Message {
    return new Message(msg)
}

export function rosLog(msg, topic: Topic, level) {

    const message = getMessage({
        name: "firebase_coms",
        level,
        msg,
    })
    try {
        topic.publish(message)
    } catch (error) {
        // Ignore
    }
}

