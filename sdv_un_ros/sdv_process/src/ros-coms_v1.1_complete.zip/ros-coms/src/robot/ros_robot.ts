import { get } from "lodash"
import { Ros, Topic, Message } from "roslib";

import { Robot } from '../../firebase-coms/src/interfaces'
import { getTopic, rosLog, logLvl } from "./ros_utils"


export class RosRobot extends Robot {
  
  private master_url: string;
  private name: string;
  private ros: Ros
  private commandTopic: Topic;
  private resultTopic: Topic;

  constructor(name, ip = 'ws://localhost:9090') {
    super()
    this.master_url = ip
    this.name = name
  }

  get id(): string {
    return this.name
  }

  async start(): Promise<boolean> {
    return this.configRos()
  }

  processCommand(type: string, args: any, onSuccess: () => void, onError: (error: string) => void, onWarning?: (warning: string) => void): void {
    const data = JSON.stringify({ type, args })
    const rosMsg = new Message({ data })

    this.commandTopic.publish(rosMsg)

    var hasFinished = false
    this.resultTopic.subscribe(message => {
      this.resultTopic.unsubscribe()
      if (hasFinished) return
      hasFinished = true
      const data = get(message, 'data')
      const result = JSON.parse(data)
      console.log('step result', result)
      if (result.success) onSuccess()
      else if (result.error)
        onError(result.error)
    })
  }

  async stop(): Promise<boolean> {
    if (this.ros)
      this.ros.close()
    return true
  }


  async configRos(): Promise<boolean> {

    const options = {
      url: this.master_url,
      encoding: "ascii"
    }

    if (this.ros) this.ros.close()

    this.ros = new Ros(options);

    this.commandTopic = getTopic(this.ros, '/step_command', 'std_msgs/String')
    this.resultTopic = getTopic(this.ros, '/step_result', 'std_msgs/String')

    const id = this.name
    const connectResult = new Promise<boolean>((resolve) => {
      this.ros.on('connection', () => {
        resolve(true)
      });
      this.ros.on('error', (error) => {
        console.error(`Error connecting to websocket ${id} server:`, error);
        this.onDisconnect()
        
        resolve(false)
      });
      this.ros.on('close', () => {
        console.log(`Connection to websocket ${id} server closed.`);
        this.onDisconnect()
        
        resolve(false)
      });
    })

    return connectResult;
  }


}