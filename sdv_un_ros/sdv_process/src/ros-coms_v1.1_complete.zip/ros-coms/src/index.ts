import { App } from '../firebase-coms/src/App'
import { RosRobot } from './robot';
import { ProcessManager } from '../firebase-coms/src/managers';


const port = process.env.PORT || 3000
const rosip = process.env.IP
const name = process.env.NAME || 'MAYA'

function init() {

    var rob = new RosRobot(name, rosip)
    var pm = new ProcessManager(rob)

    const app = new App(pm)

    app.start(port)
}

init()