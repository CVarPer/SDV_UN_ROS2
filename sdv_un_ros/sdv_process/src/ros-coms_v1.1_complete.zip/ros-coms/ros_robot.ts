import _ = require("lodash")
import { Ros, Topic, Message } from "roslib";

import { Robot } from "../robot"
import RobotManager from "../robot_manager"
import { getTopic, rosLog, logLvl } from "./ros_utils"
import { FirebaseManager } from "../../firebase/firebase_manager"



export class RosRobot extends Robot implements RobotManager {

  private ros: Ros
  private connected: boolean
  private master_url: string

  private stepTopic: Topic
  private beginTopic: Topic
  private updateTopic: Topic
  private receiveTopic: Topic
  private logger: Topic

  constructor(name, ip = 'ws://localhost:9090') {
    super()
    this.connected = false
    this.master_url = ip
    this.name = name
    this.firebase = new FirebaseManager(name, this)
  }

  newTask(key, task) {
    this.robotLog(`Received new task, id: ${key}`, logLvl.INFO)
    let data = JSON.stringify({ key, task })
    let rosMsg = new Message({ data })
    this.receiveTopic.publish(rosMsg)
  }

  sendStep(taskId, stepId, task) {
    let data = JSON.stringify({ taskId, stepId, task })
    let rosMsg = new Message({ data })
    this.stepTopic.publish(rosMsg)
  }

  connect(): Promise<boolean> {
    return this.configRos()
  }

  disconnect(): void {
    if (this.ros)
      this.ros.close()
    else
      this.firebase.stopTaskListener()
  }

  isConnected(): object {
    return { ros: this.connected, firebase: this.firebase.isConnected() }
  }


  robotLog(message, lvl = logLvl.DEBUG): void {
    rosLog(message, this.logger, lvl)
  }

  async configRos(): Promise<boolean> {

    const options = {
      url: this.master_url,
      encoding: "ascii"
    }

    if (this.ros) this.ros.close()

    this.ros = new Ros(options);

    this.stepTopic = getTopic(this.ros, '/task_step', 'std_msgs/String')
    this.beginTopic = getTopic(this.ros, '/task_begin', 'std_msgs/String')
    this.updateTopic = getTopic(this.ros, '/task_update', 'std_msgs/String')
    this.receiveTopic = getTopic(this.ros, '/task_receive', 'std_msgs/String')

    this.logger = getTopic(this.ros, '/rosout', 'rosgraph_msgs/Log')

    this.beginTopic.subscribe(message => {
      console.log('starting new task')
      this.firebase.processTask(_.get(message, 'data'))
    })
    this.updateTopic.subscribe(message => {
      console.log(`updating task with ${_.get(message, 'data', "")}`)
      this.firebase.updateTask(_.get(message, 'data'))
    })


    const id = this.name
    const connectResult = new Promise<boolean>((resolve) => {
      this.ros.on('connection', () => {
        this.robotLog(`Connected to websocket ${id} server.`)
        this.connected = true
        this.firebase.startTaskListener()
        resolve(true)
      });
      this.ros.on('error', (error) => {
        console.error(`Error connecting to websocket ${id} server:`, error);
        this.connected = false
        resolve(false)
      });
      this.ros.on('close', () => {
        console.log(`Connection to websocket ${id} server closed.`);
        this.connected = false
        this.firebase.stopTaskListener()
        resolve(false)
      });
    })

    return connectResult;
  }


}